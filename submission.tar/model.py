from torch import nn
from torch.nn import functional as F
import torchvision
import numpy as np
import torch


class Flatten(nn.Module):
    """
    Implement a simple custom module that reshapes (n, m, 1, 1) tensors to (n, m).
    """
    def forward(self, x):
        out = x.view(len(x), -1)
        return out


class Audio(nn.Module):
    def __init__(self, nclasses):
        super(Audio, self).__init__()
        self.nclasses = nclasses
        self.conv1 = nn.Conv2d(in_channels=1, out_channels=16, kernel_size=7, stride=(1, 3), padding=0, dilation=2, bias=False)
        self.bn1 = nn.BatchNorm2d(16)
        self.rel1 = nn.ReLU()
        self.conv2 = nn.Conv2d(in_channels=16, out_channels=32, kernel_size=5, stride=(1, 2), padding=0, dilation=1, bias=False)
        self.bn2 = nn.BatchNorm2d(32)
        self.rel2 = nn.ReLU()
        self.conv3 = nn.Conv2d(in_channels=32, out_channels=64, kernel_size=5, stride=(1, 2), padding=0, dilation=1, bias=False)
        self.rel3 = nn.ReLU()
        self.drop1 = nn.Dropout(0.2)
        self.conv4 = nn.Conv2d(in_channels=64, out_channels=64, kernel_size=3, stride=(1, 1), padding=0, dilation=1, bias=False)
        self.rel4 = nn.ReLU()
        self.pool1 = nn.AvgPool2d((1, 71))
        self.pool2 = nn.AvgPool2d((7, 1))
        self.flatten = Flatten()
        self.drop2 = nn.Dropout(0.2)
        self.lin1 = nn.Linear(2304, 512, bias=False)
        self.clf = nn.Linear(300, nclasses, bias=False)

    def forward(self, x):
        x = self.rel1(self.bn1(self.conv1(x)))
        x = self.rel2(self.bn2(self.conv2(x)))
        x = self.rel3(self.conv3(x))
        x = self.rel4(self.conv4(self.drop1(x)))
        x = self.pool1(x)
        x = self.pool2(x)
        x = self.flatten(x)
        x = self.drop2(x)
        x = self.lin1(x)
        x = F.sigmoid(x)
        x = self.clf(x)
        return x


def all_cnn_module(nclasses):
    net = []

    net.append(nn.Dropout(0.2))
    net.append(nn.Conv2d(in_channels=1, out_channels=96, kernel_size=7, stride=(1, 4), padding=0, dilation=1, groups=1))
    net.append(nn.ReLU())
    net.append(nn.Conv2d(in_channels=96, out_channels=96, kernel_size=5, stride=(1, 2), padding=0, dilation=1, groups=1))
    net.append(nn.ReLU())
    net.append(nn.Conv2d(in_channels=96, out_channels=96, kernel_size=5, stride=(1, 2), padding=0, dilation=1, groups=1))
    net.append(nn.ReLU())
    net.append(nn.Conv2d(in_channels=96, out_channels=96, kernel_size=3, stride=(1, 2), padding=0, dilation=1, groups=1))
    net.append(nn.ReLU())
    net.append(nn.Conv2d(in_channels=96, out_channels=96, kernel_size=3, stride=(1, 2), padding=0, dilation=1, groups=1))
    net.append(nn.ReLU())

    net.append(nn.Dropout(0.5))
    net.append(nn.Conv2d(in_channels=96, out_channels=192, kernel_size=3, stride=1, padding=0))
    net.append(nn.ReLU())
    net.append(nn.Conv2d(in_channels=192, out_channels=192, kernel_size=3, stride=1, padding=0))
    net.append(nn.ReLU())
    net.append(nn.Conv2d(in_channels=192, out_channels=192, kernel_size=3, stride=(1, 2), padding=0))
    net.append(nn.ReLU())

    net.append(nn.Dropout(0.5))
    net.append(nn.Conv2d(in_channels=192, out_channels=192, kernel_size=3, stride=1, padding=1))
    net.append(nn.ReLU())
    net.append(nn.Conv2d(in_channels=192, out_channels=192, kernel_size=1, stride=1, padding=0))
    net.append(nn.ReLU())
    net.append(nn.Conv2d(in_channels=192, out_channels=20, kernel_size=1, stride=1, padding=0))
    net.append(nn.ReLU())

    net.append(nn.AvgPool2d((1, 8)))
    net.append(nn.AvgPool2d((5, 1)))
    net.append(Flatten())

    # net.append(nn.Linear(1440, 1440 * 2))
    # net.append(nn.Linear(1440 * 2, 192 * 2))
    # net.append(nn.Linear(192 * 2, 100))
    # net.append(nn.Linear(100, nclasses))

    net = nn.Sequential(*net)
    return net


class AudioDenseNet(nn.Module):
    '''
    Implementation heavily inspired by Torchvision's Densenet.
    This is the model used for final output.
    '''

    def __init__(self, classnum):

        super(AudioDenseNet, self).__init__()

        # First convolution
        self.features = nn.Sequential(
            nn.Conv2d(3, 64, kernel_size=7, stride=2, padding=3, bias=False),
            nn.BatchNorm2d(64),
            nn.ReLU(inplace=True),
            nn.MaxPool2d(kernel_size=3, stride=2, padding=1),
            # blocks of (6, 12, 24, 16), 64 initial features
            torchvision.models.densenet._DenseBlock(num_layers=6, num_input_features=64,
                                                    bn_size=4, growth_rate=32, drop_rate=0),
            torchvision.models.densenet._Transition(num_input_features=256, num_output_features=128),
            torchvision.models.densenet._DenseBlock(num_layers=12, num_input_features=128,
                                                    bn_size=4, growth_rate=32, drop_rate=0),
            torchvision.models.densenet._Transition(num_input_features=512, num_output_features=256),
            torchvision.models.densenet._DenseBlock(num_layers=24, num_input_features=256,
                                                    bn_size=4, growth_rate=32, drop_rate=0),
            torchvision.models.densenet._Transition(num_input_features=1024, num_output_features=512),
            torchvision.models.densenet._DenseBlock(num_layers=16, num_input_features=512,
                                                    bn_size=4, growth_rate=32, drop_rate=0),
            nn.BatchNorm2d(1024)
        )

        self.strider = nn.Conv2d(1, 3, (7, 15), (1, 8), (3, 0))
        self.avg_pool = nn.AvgPool2d(kernel_size=(1, 29))
        self.embeddings = nn.Linear(4096, 300, bias=False)
        self.clf = nn.Linear(300, classnum, bias=False)
        if torch.cuda.is_available():
            self.alpha = torch.from_numpy(np.array(16)).float().cuda()
        else:
            self.alpha = torch.from_numpy(np.array(16)).float()

        # initialize
        for m in self.modules():
            if isinstance(m, nn.Conv2d):
                nn.init.kaiming_normal_(m.weight)
            elif isinstance(m, nn.BatchNorm2d):
                nn.init.constant_(m.weight, 1)
                nn.init.constant_(m.bias, 0)

    def forward(self, x):
        x = self.strider(x)
        x = F.elu(x)
        x = self.features(x)
        x = F.relu(x, inplace=True)
        x = self.avg_pool(x).view(x.size(0), -1)
        x = self.embeddings(x)
        x = F.normalize(x) * self.alpha
        x = F.sigmoid(x)
        x = self.clf(x)
        return x


if __name__=='__main__':
    import torchsummary

    # net = all_cnn_module(127)
    # print(torchsummary.summary(net, (1, 64, 384)))

    # net = Audio(127)
    # print(torchsummary.summary(net, (1, 64, 5184)))
    # print(net._modules)

    net = AudioDenseNet(127)
    print(torchsummary.summary(net, (1, 64, 468*32)))
    # print(net._modules)
